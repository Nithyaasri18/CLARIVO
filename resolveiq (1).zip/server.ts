import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { runResolutionPipeline } from './src/engine';
import { CustomerRecord } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json());

// Helper to load JSON files safely
function loadData<T>(fileName: string, fallback: T): T {
  const filePath = path.join(process.cwd(), 'data', fileName);
  if (fs.existsSync(filePath)) {
    try {
      return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    } catch (e) {
      console.error(`Error reading ${fileName}:`, e);
    }
  }
  return fallback;
}

function saveData<T>(fileName: string, data: T): void {
  const filePath = path.join(process.cwd(), 'data', fileName);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Clarivo Copilot', port: PORT });
});

// Cases list
app.get('/api/cases', (req, res) => {
  const cases = loadData<any[]>('cases.json', []);
  res.json(cases);
});

// Single case details + pipeline output
app.get('/api/cases/:id', async (req, res) => {
  const caseId = req.params.id;
  const cases = loadData<any[]>('cases.json', []);
  const currentCase = cases.find((c) => c.case_id === caseId);

  if (!currentCase) {
    return res.status(404).json({ error: 'Case not found' });
  }

  const customers = loadData<CustomerRecord[]>('customers.json', []);
  const customer = customers.find((c) => c.customer_id === currentCase.customer_id);

  if (!customer) {
    return res.status(404).json({ error: 'Customer not found' });
  }

  const pipeline = await runResolutionPipeline({
    caseId,
    message: currentCase.initial_message,
    customer,
  });

  res.json({
    case: currentCase,
    customer,
    pipeline,
  });
});

// Case action (approve, clarify, escalate)
app.post('/api/cases/:id/action', (req, res) => {
  const caseId = req.params.id;
  const { action, notes } = req.body;
  const cases = loadData<any[]>('cases.json', []);
  const idx = cases.findIndex((c) => c.case_id === caseId);

  if (idx === -1) {
    return res.status(404).json({ error: 'Case not found' });
  }

  let newStatus = cases[idx].status;
  if (action === 'APPROVE') newStatus = 'RESOLVED';
  else if (action === 'SEND_CLARIFICATION') newStatus = 'AWAITING_INFO';
  else if (action === 'CONFIRM_ESCALATION') newStatus = 'ESCALATED';

  cases[idx].status = newStatus;
  cases[idx].updated_at = new Date().toISOString().replace('T', ' ').slice(0, 19);
  saveData('cases.json', cases);

  res.json({ case_id: caseId, status: newStatus, action, notes });
});

// Run live simulation on customer query
app.post('/api/simulate', async (req, res) => {
  const { customer_id, message, case_id } = req.body;
  if (!customer_id || !message) {
    return res.status(400).json({ error: 'customer_id and message are required' });
  }

  const customers = loadData<CustomerRecord[]>('customers.json', []);
  const customer = customers.find((c) => c.customer_id === customer_id);
  if (!customer) {
    return res.status(404).json({ error: `Customer ${customer_id} not found` });
  }

  try {
    const pipeline = await runResolutionPipeline({
      caseId: case_id,
      message,
      customer,
    });

    // Update or insert into cases.json
    const cases = loadData<any[]>('cases.json', []);
    const existingIdx = cases.findIndex((c) => c.case_id === pipeline.case_id);
    const caseRecord = {
      case_id: pipeline.case_id,
      customer_id: customer.customer_id,
      customer_name: customer.name,
      issue_title: message.slice(0, 75),
      initial_message: message,
      status:
        pipeline.decision === 'RESOLUTION'
          ? 'RESOLVED_DRAFT'
          : pipeline.decision === 'MISSING_INFO'
          ? 'AWAITING_INFO'
          : 'ESCALATED',
      intent: pipeline.intent,
      confidence: pipeline.confidence,
      decision: pipeline.decision,
      created_at: new Date().toISOString().replace('T', ' ').slice(0, 19),
      updated_at: new Date().toISOString().replace('T', ' ').slice(0, 19),
    };

    if (existingIdx >= 0) {
      cases[existingIdx] = { ...cases[existingIdx], ...caseRecord };
    } else {
      cases.unshift(caseRecord);
    }
    saveData('cases.json', cases);

    res.json(pipeline);
  } catch (err: any) {
    console.error('Simulation error:', err);
    res.status(500).json({ error: err.message || 'Simulation failed' });
  }
});

// Customers list
app.get('/api/customers', (req, res) => {
  const customers = loadData<CustomerRecord[]>('customers.json', []);
  res.json(customers);
});

// Single customer
app.get('/api/customer/:id', (req, res) => {
  const customers = loadData<CustomerRecord[]>('customers.json', []);
  const customer = customers.find((c) => c.customer_id === req.params.id);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });
  res.json(customer);
});

// Knowledge Base articles
app.get('/api/kb', (req, res) => {
  const articles = loadData<any[]>('kb_articles.json', []);
  const { category, search } = req.query;
  let filtered = articles;
  if (category) {
    filtered = filtered.filter((a) => a.category === category);
  }
  if (search && typeof search === 'string') {
    const s = search.toLowerCase();
    filtered = filtered.filter(
      (a) =>
        a.title.toLowerCase().includes(s) ||
        a.body.toLowerCase().includes(s) ||
        a.id.toLowerCase().includes(s) ||
        a.keywords?.some((k: string) => k.toLowerCase().includes(s))
    );
  }
  res.json(filtered);
});

// Benchmark scenarios
app.get('/api/scenarios', (req, res) => {
  const scenarios = loadData<any[]>('scenarios.json', []);
  res.json(scenarios);
});

// -------------------------------------------------------------
// Vite Middleware / Static Server
// -------------------------------------------------------------
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Clarivo server running on http://0.0.0.0:${PORT}`);
  });
}

start();
